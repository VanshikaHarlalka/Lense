// The Description is returned as Markdown, of course.
let markdownIt = document.createElement('script')
markdownIt.src = 'https://cdnjs.cloudflare.com/ajax/libs/markdown-it/12.3.2/markdown-it.min.js';
document.head.appendChild(markdownIt)



const setBasics = (data) => {
	document.title = data.title
	document.getElementById('channel-title').innerHTML = data.title
	document.getElementById('channel-description').innerHTML = window.markdownit().render(data.metadata.description)

	// Add author/collaborators with image/links.
	// Error proof these.
}



const parseBlocks = (data) => {
	let blocks = [
		'audioEmbed',
		'audioFile',
		'image',
		'link',
		'pdf',
		'text',
		'videoEmbed',
		'videoFile',
	]

	blocks.forEach((type) => {
		let typeClass = type.replace(/[A-Z]/g, "-$&").toLowerCase()
		let typeName = type.split(/[A-Z]/g)[0];
		(typeName == 'pdf') ? typeName = typeName.toUpperCase() : typeName = typeName[0].toUpperCase() + typeName.slice(1)

		let typeContainer = document.querySelector(`.${typeClass}-blocks`)
		let typeTemplate = document.getElementById(`${typeClass}-block`)

		blocks[type] = {
			name: typeName,
			container: typeContainer,
			template: typeTemplate ? typeTemplate.content : null,
		}
	})

	data.contents.slice().reverse().forEach((block) => {
		switch (block.class) {
			case 'Attachment':
				let attachment = block.attachment.content_type
				if (attachment.includes('audio')) {
					renderBlock(block, blocks.audioFile)
				}
				else if (attachment.includes('pdf')) {
					renderBlock(block, blocks.pdf)
				}
				else if (attachment.includes('video')) {
					renderBlock(block, blocks.videoFile)
				}
				break

			case 'Image':
				renderBlock(block, blocks.image)
				break

			case 'Link':
				renderBlock(block, blocks.link)
				break

			case 'Media':
				let media = block.embed.type
				if (media.includes('rich')) {
					renderBlock(block, blocks.audioEmbed)
				}
				else if (media.includes('video')) {
					renderBlock(block, blocks.videoEmbed)
				}
				break

			case 'Text':
				renderBlock(block, blocks.text)
				break
		}
	})
}



const renderBlock = (block, type) => {
	if (!type.template || !type.container) return

	let template = type.template.cloneNode(true)
	let element = [
		'title',
		'image',
		'embed',
		'audio',
		'video',
		'link',
		'linkTitle',
		'content',
		'description',
		'type',
	]

	element = Object.assign({},
		...element.map(type => ({
			[type]: template.querySelector(`.${type.replace(/[A-Z]/g, "-$&").toLowerCase()}`)
		}))
	)

	if (element.title) block.title ? element.title.innerHTML = block.title : element.title.remove()
	if (element.image) block.image ? element.image.src = block.image.large.url : element.image.remove()
	if (element.embed) block.embed ? element.embed.innerHTML = block.embed.html : element.embed.remove()
	if (element.audio) block.attachment ? element.audio.src = block.attachment.url : element.audio.remove()
	if (element.video) block.attachment ? element.video.src = block.attachment.url : element.video.remove()
	if (element.link) {
		if (block.source) {
			element.link.href = block.source.url
			if (element.linkTitle) element.linkTitle.innerHTML = block.source.title
		}
		else if (block.attachment) {
			element.link.href = block.attachment.url
			if (element.linkTitle) element.linkTitle.innerHTML = block.title
		}
		else {
			element.link.remove()
			element.linkTitle.remove()
		}
	}
	if (element.content) block.content_html ? element.content.innerHTML = block.content_html : element.content.remove()
	if (element.description) block.description_html ? element.description.innerHTML = block.description_html : element.description.remove()
	if (element.type) element.type.innerHTML = type.name

	type.container.append(template)
}



window.addEventListener('DOMContentLoaded', () => {
	const channel = document.getElementById('channel-url').href.split('/').filter(Boolean).pop()

	fetch(`https://api.are.na/v2/channels/${channel}?per=100`, {cache: 'no-store'})
		.then(response => response.json())
		.then(data => {
			setBasics(data)
			parseBlocks(data)
		})
});

document.addEventListener('DOMContentLoaded', function () {
    var video = document.getElementById('video-bg');
    video.playbackRate = 0.7; // Set playback rate to half speed (0.5x)
});

const cursor = document.getElementById("custom-cursor");

document.addEventListener("mousemove", (e) => {
    // Update cursor position based on mouse coordinates
    cursor.style.left = e.clientX + "px";
    cursor.style.top = e.clientY + "px";
});

window.addEventListener('scroll', function() {
    // Get the current scroll position
    var scrollPosition = window.scrollY;

    // Calculate text size based on scroll position
    var newSize = 24 + (scrollPosition * 0.02); // Example calculation

    // Calculate opacity based on scroll position
    var newOpacity = 1 - (scrollPosition * 0.002); // Example calculation

    // Apply new styles to the text
    document.querySelectorAll('.line1').forEach(function(paragraph) {
        paragraph.style.fontSize = newSize + 'px';
        paragraph.style.opacity = newOpacity;
    });
});

window.addEventListener('scroll', function() {
    // Get the scroll position
    var scrollPosition = window.scrollY;

    // Get the position of the line element relative to the viewport
    var linePosition = document.querySelector('.line2').getBoundingClientRect().top;

    // Check if the line is above the viewport (not in view)
    if (linePosition < 0) {
        // Increase font size and decrease opacity for paragraphs
        document.querySelectorAll('.line2').forEach(function(paragraph) {
            paragraph.style.fontSize = '32px';
            paragraph.style.opacity = '0.2';
        });
    } else {
        // Reset font size and opacity when the line is in view
        document.querySelectorAll('.line2').forEach(function(paragraph) {
            paragraph.style.fontSize = '24px';
            paragraph.style.opacity = '1';
        });
    }
});


window.addEventListener('scroll', function() {
    // Get the scroll position
    var scrollPosition = window.scrollY;

    // Get the position of the line element relative to the viewport
    var linePosition = document.querySelector('.line3').getBoundingClientRect().top;

    // Check if the line is above the viewport (not in view)
    if (linePosition < 0) {
        // Increase font size and decrease opacity for paragraphs
        document.querySelectorAll('.line3').forEach(function(paragraph) {
            paragraph.style.fontSize = '32px';
            paragraph.style.opacity = '0.2';
        });
    } else {
        // Reset font size and opacity when the line is in view
        document.querySelectorAll('.line3').forEach(function(paragraph) {
            paragraph.style.fontSize = '24px';
            paragraph.style.opacity = '1';
        });
    }
});

window.addEventListener('scroll', function() {
    // Get the scroll position
    var scrollPosition = window.scrollY;

    // Get the position of the line element relative to the viewport
    var linePosition = document.querySelector('.line4').getBoundingClientRect().top;

    // Check if the line is above the viewport (not in view)
    if (linePosition < 0) {
        // Increase font size and decrease opacity for paragraphs
        document.querySelectorAll('.line4').forEach(function(paragraph) {
            paragraph.style.fontSize = '32px';
            paragraph.style.opacity = '0.2';
        });
    } else {
        // Reset font size and opacity when the line is in view
        document.querySelectorAll('.line4').forEach(function(paragraph) {
            paragraph.style.fontSize = '24px';
            paragraph.style.opacity = '1';
        });
    }
});

function updateBackgroundColor() {
    const body = document.body;
    const hour = new Date().getHours();

    if (hour < 6) {
        body.style.backgroundColor = '#4A515D'; 
	} else if (hour < 12) {
        body.style.backgroundColor = '#383C44'; 
    } else if (hour < 18) {
        body.style.backgroundColor = '#295272';    
    } else {
        body.style.backgroundColor = '#1C2036';
    }
}

document.addEventListener('DOMContentLoaded', updateBackgroundColor);

document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('backgroundVideo');

    video.ondblclick = function() {
        if (video.style.zIndex == 9999 || video.style.zIndex == "") {
            video.style.zIndex = -100;
            video.style.opacity = 0.1;
            video.style.filter = 'grayscale(100%)';
        } else {
            video.style.zIndex = 9999;
            video.style.opacity = 1;
            video.style.filter = 'grayscale(0%)';
        }
    };
});

document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('backgroundVideo');
    let isDragging = false;

    video.addEventListener('mousedown', function(event) {
        // Start dragging
        isDragging = true;
        video.style.opacity = 0.1; // Initial state when dragging starts
        video.style.filter = 'grayscale(100%)';
    });

    document.addEventListener('mousemove', function(event) {
        if (isDragging) {
            const rect = video.getBoundingClientRect();
            const dragPosition = event.clientX - rect.left; // Horizontal position within the video

            // Calculate opacity and grayscale based on drag position
            let opacity = dragPosition / rect.width;
            let grayscale = 100 - (100 * opacity);

            video.style.opacity = Math.max(0.1, Math.min(1, opacity));
            video.style.filter = `grayscale(${grayscale}%)`;
        }
    });

    document.addEventListener('mouseup', function() {
        // Stop dragging
        if (isDragging) {
            isDragging = false;
            // Set to normal or last state after drag ends
            video.style.opacity = 1;
            video.style.filter = 'grayscale(0%)';
        }
    });
});

